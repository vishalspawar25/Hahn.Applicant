export class Notification {

    message:string;
    IsConfirmBox:boolean

}