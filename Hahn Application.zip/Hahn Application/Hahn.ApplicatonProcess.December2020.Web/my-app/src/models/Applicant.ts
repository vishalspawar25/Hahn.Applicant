import { timeStamp } from "console"

export class Applicant {

   id :number;
   name:string;
   familyName:string;
   address:string;
   countryOfOrigin:string;
   email:string;
   age:number;
   isHired:boolean=false;

  }
  