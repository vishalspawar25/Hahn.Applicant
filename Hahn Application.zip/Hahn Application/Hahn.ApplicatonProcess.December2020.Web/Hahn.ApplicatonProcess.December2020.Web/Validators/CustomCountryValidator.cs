﻿using FluentValidation;
using FluentValidation.Validators;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;

namespace Hahn.ApplicatonProcess.December2020.Web.Validators
{
    public class CustomCountryValidator:PropertyValidator
    {
        public CustomCountryValidator() : base("Country name- {PropertyValue} is not a valid ")
        {
        }
        protected override bool IsValid(PropertyValidatorContext context)
        {
            string countryname = (string)context.PropertyValue;
            using (var client = new HttpClient())
            {
                var url = @"http://restcountries.eu/rest/v2/name/" + countryname + "? fullText=true";
                var responseTask = client.GetAsync(url);
                responseTask.Wait();
                var result = responseTask.Result;
                if (result.IsSuccessStatusCode)
                {                   
                    return true;
                }
                else
                    return false;
            }
        }
    }

    public static class CustomValidatorExtensions
    {
        public static IRuleBuilderOptions<T, string> ValidCountry<T>(
            this IRuleBuilder<T, string> ruleBuilder)
        {
            return ruleBuilder.SetValidator(new CustomCountryValidator());
        }
    }
}
