﻿using System;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.EntityFrameworkCore;
namespace Hahn.ApplicatonProcess.December2020.Data
{
    public class root
    {
        public static void injectDependencies(IServiceCollection services)
        {
            services.AddDbContext<HahnAppContext>(opts => opts.UseInMemoryDatabase("HahnDB"));
            services.AddScoped<HahnAppContext>();           
        }
    }
}
