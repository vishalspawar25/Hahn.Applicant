﻿using Hahn.ApplicatonProcess.December2020.Data.models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Text;

namespace Hahn.ApplicatonProcess.December2020.Data
{
    
    public class HahnAppContext : DbContext
    {
        public HahnAppContext(DbContextOptions<HahnAppContext> options)
            : base(options)
        {
        }
         public DbSet<Applicant> Applicants { get; set; }
    }
}
